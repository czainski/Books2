﻿namespace BO
{
 public class DepartureGroup
 {
  public string Departure { get; set; }
  public int FlightCount { get; set; }
 }
}
