﻿using System;
using System.Collections.Generic;

namespace EFC_WWWingsV1_Reverse
{
    public partial class Test
    {
        public string Test1 { get; set; }
        public string Event { get; set; }
    }
}
