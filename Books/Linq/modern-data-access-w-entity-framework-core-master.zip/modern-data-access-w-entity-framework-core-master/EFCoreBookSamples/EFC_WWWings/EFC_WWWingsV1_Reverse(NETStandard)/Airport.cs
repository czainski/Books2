﻿using System;
using System.Collections.Generic;

namespace EFC_WWWingsV1_Reverse
{
    public partial class Airport
    {
        public string Name { get; set; }
        public int? Typ { get; set; }
    }
}
