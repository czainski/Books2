﻿using System;
using System.Collections.Generic;

namespace EFC_WWWingsV1_Reverse
{
    public partial class Metadaten
    {
        public string Surname { get; set; }
        public string Value { get; set; }
        public byte[] Timestamp { get; set; }
        public string Memo { get; set; }
    }
}
