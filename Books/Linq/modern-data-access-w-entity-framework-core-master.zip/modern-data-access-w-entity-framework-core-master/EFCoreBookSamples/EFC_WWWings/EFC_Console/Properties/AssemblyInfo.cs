﻿
using System.Reflection;

[assembly: AssemblyTitle("EFC_Console")]