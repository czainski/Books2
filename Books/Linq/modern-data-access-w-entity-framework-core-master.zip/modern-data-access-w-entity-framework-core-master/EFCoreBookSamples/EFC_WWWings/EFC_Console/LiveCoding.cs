﻿using BO;
using ITVisions;
using ITVisions.EFCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFC_Console
{

 /// <summary>
 /// Live-Coding placeholder
 /// </summary>
 class LiveCoding
 {

  public static void Run()
  {

   // TODO: your code
  }

 }
}
