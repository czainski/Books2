﻿namespace EFC_BO_Step1
{
    public class Class1
    {
    }
}
