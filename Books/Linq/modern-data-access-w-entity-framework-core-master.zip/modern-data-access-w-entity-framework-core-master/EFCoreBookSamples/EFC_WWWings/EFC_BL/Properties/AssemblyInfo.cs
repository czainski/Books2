﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("EFC_GL")]
[assembly: ComVisible(false)]
[assembly: Guid("5044bded-33d3-4baf-9337-66608cc52c71")]
