using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Entity Framework Core Samples for EFCore v2.1 Preview 1")]
[assembly: AssemblyCompany("www.IT-Visions.de")]
[assembly: AssemblyCopyright("Copyright � Dr. Holger Schwichtenberg 2009-2018")]

[assembly: AssemblyVersion("2018.03.20.0")]
[assembly: AssemblyFileVersion("2018.03.20.0")]
