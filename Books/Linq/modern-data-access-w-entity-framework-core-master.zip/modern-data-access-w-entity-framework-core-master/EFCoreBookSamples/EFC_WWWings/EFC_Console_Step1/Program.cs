﻿using System;
using EFC_Console;

namespace EFC_Console_Step1
{
    class Program
    {
        static void Main(string[] args)
        {
         SampleClientForward.Run();
        }
    }
}
