﻿Set start project to "EFC_Tools"
Open Package Manager Console
Set defafult project to "EFC_DA"

Create migration (if it does not exist): add-migration v1
Create local database: update-database