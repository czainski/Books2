﻿using System;
using System.Collections.Generic;

namespace EFC_WWWings1_Reverse_NETFX_
{
    public partial class Airport
    {
        public string Name { get; set; }
        public int? Typ { get; set; }
    }
}
