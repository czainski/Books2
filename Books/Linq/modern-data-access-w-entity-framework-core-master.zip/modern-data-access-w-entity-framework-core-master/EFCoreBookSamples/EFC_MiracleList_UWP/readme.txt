MiracleList Light (EFC_UWP) is a sample application for simple task management app, implemented as a Windows Universal Platform (UWP) app for Windows 10 with Entity Framework Core using a local SQLite database or Microsoft SQL Server. (C) Dr. Holger Schwichtenberg, www.IT-Visions.de, 2016-2018

-----

Version 4.0 24.1.2018: Update to EFCore 2.0 und UWP 6.0. Added optional support for SQL Server
version 4.1 26.1.2018: Move EFCore Context and Entity Classes to DAL project (.NET Standard 2.0)